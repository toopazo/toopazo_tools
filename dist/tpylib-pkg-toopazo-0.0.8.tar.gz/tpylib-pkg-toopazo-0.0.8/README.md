# toopazo_pylib
Python library for different tasks


https://packaging.python.org/tutorials/packaging-projects/
https://test.pypi.org/manage/account/token/

pypi-AgENdGVzdC5weXBpLm9yZwIkZWI2NTlhMTYtNTY1Zi00OWUyLWE4YWUtODA5MmYzMjQzMmQwAAIleyJwZXJtaXNzaW9ucyI6ICJ1c2VyIiwgInZlcnNpb24iOiAxfQAABiCbvN4oyBi1ILFoWDZQRPvbgzqTjEGj3p3EuFgo5-zq4w

https://test.pypi.org/project/tpylib-pkg-toopazo/0.0.1/

python3 -m pip install --index-url https://test.pypi.org/simple/ --no-deps tpylib-pkg-toopazo



